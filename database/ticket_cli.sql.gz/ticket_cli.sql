-- Adminer 4.8.1 MySQL 5.5.5-10.4.21-MariaDB dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

CREATE DATABASE `ticket_cli` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `ticket_cli`;

CREATE TABLE `ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` varchar(25) DEFAULT NULL,
  `ticket_code` text DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0 COMMENT '0 = available , 1 = claimed',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticket_code` (`ticket_code`) USING HASH
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `ticket` (`id`, `event_id`, `ticket_code`, `status`, `created_at`, `updated_at`) VALUES
(1,	'1',	'DTKExFppQ3',	1,	'2022-03-19 09:41:54',	'2022-03-19 12:27:36'),
(2,	'1',	'DTK5OGUCCG',	0,	'2022-03-19 09:41:54',	NULL),
(3,	'1',	'DTKJBLe45n',	0,	'2022-03-19 09:41:54',	NULL),
(4,	'1',	'DTKrp1xAfg',	0,	'2022-03-19 09:41:54',	NULL),
(5,	'1',	'DTKthbmcv5',	0,	'2022-03-19 09:41:54',	NULL),
(6,	'1',	'DTKQl8zlIJ',	0,	'2022-03-19 09:41:54',	NULL),
(7,	'1',	'DTKlAj4dNc',	0,	'2022-03-19 09:41:54',	NULL),
(8,	'1',	'DTKlRRZD0Y',	0,	'2022-03-19 09:41:54',	NULL),
(9,	'1',	'DTKN7SKEMO',	0,	'2022-03-19 09:41:54',	NULL),
(10,	'1',	'DTKmQiJV1U',	0,	'2022-03-19 09:41:54',	NULL);

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1,	'admin',	'900150983cd24fb0d6963f7d28e17f72');

-- 2022-03-19 05:36:03
